a = 4
b = 6
print("Összeg: ", a+b)
name = input('Add meg a nevedet:')  #szöveg kiiratása
print("Hello",name,"!")  #szöveg kiiratása az elötte bekért adatokkal
#kereszt_nev - Python
#keresztNev - Java
#ugyanez + jellel elválasztva
#konkatenáció, összefűzés
print("Hello "+name+" !")

szam = input('Írj be két egész számot')
a = int(input("Első:"))
b = int(input("Második:"))
c = a*b
print("A két szám szorzata: ",c)

tort = int(input('Most írj be egy egész és egy tört számot'))
d = float(input("Első:"))
e = int(input("Második:"))
f = d*e
print("A két törtszám szorzata:",f)

teljes = int (input("Szeretném tudni a teljes nevedet."))
vezetek = int (input("Add meg légyszives a vezetéknevedet"))
print("Üdvözöllek",vezetek, " ",name,"! :)")