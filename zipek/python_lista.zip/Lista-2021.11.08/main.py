import list
import csoportmunka
#csoportmunka.otosfeladat()
#csoportmunka.elsofeladat()
#csoportmunka.masodikfeladat()
csoportmunka.novekvo()