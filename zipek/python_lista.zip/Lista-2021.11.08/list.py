#Első feladat
#Kérj be 5 szót, majd minden elemét tedd egy listába!
fruits = []
def elso():
    input("Írj be 5 gyümölcsöt amiből majd egy listát tudunk csinálni")
    leghosszabb = 0
    for i in range(5):
        gyumolcs = input("Írj be egy gyümölcsöt")
        fruits.append(gyumolcs)
    print(fruits)

#első feladat közösen
def elso_a_masik():
    lista = []
    for i in range(5):
        szo = input("Kérek egy szót")
        lista.append(szo)
    print(lista)

#elso feladat a része
def longestnum():
    print("Add meg a leghosszabb szó hosszát!")
    #longestnum
    longest = ""
    for i in range(len(fruits)):
        if len(longest) < len(fruits[i]):
            longest = fruits[i]
    print("A lista leghosszabb eleme: ", longest)

