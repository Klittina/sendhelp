def otosfeladat():
    print("Cseréld ki az almákat körtére!")
    ilst  = ["kecske", "alma", "péntek", "nem", "talán", "alma"]
    print(ilst)
    mennyi = ilst.count("alma")
    print(mennyi)
    for i in range (mennyi):
        ilst.remove("alma")
        ilst.append("körte")
    print(ilst)

def elsofeladat():
    mondat = []
    szo = input("Írj be egy szót.")
    szo = szo.capitalize()
    mondat.append(szo)
    mondat2=szo
    for i in range (4):
        szo = input("Írj be egy szót.")
        mondat.append(szo)
        mondat2 = mondat2 + " "+ szo
    print(mondat)
    print(mondat2 + ".")

def masodikfeladat():
    print("Kérj be 5 szót keresd meg a legkisebbet és ha van benne “L”(nem a méret a lényeg) betű töröld a listából ha nincs hagyd benne")
    otszo = []
    for i in range(5):
        szo = input("Írj be egy szót.")
        otszo.append(szo)
    print(otszo , "Ez lett az elkészültt lista. Most keressük meg a legrövidebb szót.")
    rovid = szo
    for i in range(len(otszo)):
        if len(rovid) > len(otszo[i]):
            rovid = otszo[i]
    print("A lista legrövidebb eleme: "+ rovid)
    l = rovid.find("l" or "L")
    print(l)
    if (l <= 20):
        otszo.remove(rovid)
    print("A végleges lista: ", otszo)

#2021.11.15. folytatása az elöző órának

lista = [2,3,4,56,67]

def novekvo():
    #megnézzük h növekvő sorrendbe vannak e a számok
    i = 0
    print(lista)
    #sorozaton belül legyünk és a feltételünk...
    vege = len(lista)-1
    while i < vege and lista[i] < lista[i+1]:
        i+=1
    if i < vege:
        print("Nem növekvő sorrendben van.")
    else:
        print("Növekvő sorrendbe van.")