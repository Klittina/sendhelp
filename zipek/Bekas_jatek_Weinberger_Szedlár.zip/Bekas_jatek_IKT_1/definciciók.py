def swap(tomb, alulvonashelye, b):
    tomb[alulvonashelye], tomb[b] = tomb[b], tomb[alulvonashelye]
    print(*tomb)

def lepesek(tomb, alulvonashelye, b ):
    if alulvonashelye-b <=2 and alulvonashelye-b>=-2:
        print("Helyes")
        swap(tomb, alulvonashelye, b)
    else:
        print("Rossz")

def helyeslepes(tomb, alulvonashelye, b, helpdesk):
    if helpdesk == -1:
        if alulvonashelye - b > 0:
            lepesek()
    elif helpdesk == 1:
        if alulvonashelye - b < 0:
            lepesek()
    else:
        print("Helytelen lépés")
