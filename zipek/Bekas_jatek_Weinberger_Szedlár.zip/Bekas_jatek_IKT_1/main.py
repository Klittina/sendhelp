import definciciók

def main(x1 = "x1", x2 = "x2", x3 = "x3", alulvonas = "_", egy = "01", ketto = "02", harom = "03",helpdesk = 1):
    # értéket adtam az elemeknek,amiket a listába raktam, mert így egyszerűbb rájuk hivatkozni mintha egyesével beirogatnám őket stringként. Így is egy stringes listáról beszélünk, de egyszerűbb hivatkozni az egyes elemekre.#
    tomb = [harom, ketto, egy, alulvonas, x1, x2, x3]
    # csak két lehetséges megoldás létezik a játékba, így ha eltérünk ezektől, akkor ugyis veszítünk.
    megoldas1 = [3, 4, 2, 1, 3, 5, 6, 4, 2, 0, 1, 3, 5, 4, 2, 3]
    print()
    print("Tereld át a baloldali békákat jobb oldalra, a jobboldali békákat pedig bal oldalra!")
    print("A békák maximum 1 társukat tudják átugrani egyszerre")
    print("Ha bármikor elrontottad a játékot, akkor írd be hogy restart - vagy r - , és újra fog indulni a játék! :)")
    print()
    print(*tomb)
    print("Vigyázz! A helytelenül beadott lépések ujrainditják a játékot! Jó szórakozást!")
    while tomb != [x1, x2, x3, alulvonas, egy, ketto, harom]:
        bevitel = input("Melyikkel szeretnél először lépni? Írd be a karaktert, és a számát. Pl x1, vagy 02.")
        alulvonashelye = tomb.index(alulvonas)
        if bevitel == "x1": # Stringeket nem lehet cserélnni, csak inteket, így meg kell határozni hogy az adott elemek a tomben hanyadik helyen vannak, és ezzel az információval lehet tovább dolgozni. hogy hanyadik helyen lévő elemet cseréljem ki a hanyadik helyen lévő elemmel.
            b = tomb.index(x1)
            helpdesk = -1
        elif bevitel == "x2":
            b = tomb.index(x2)
            helpdesk = -1
        elif bevitel == "x3":
            b = tomb.index(x3)
            helpdesk = -1

        elif bevitel == "01":
            b = tomb.index(egy)
        elif bevitel == "02":
            b = tomb.index(ketto)
        elif bevitel == "03":
            b = tomb.index(harom)
        elif bevitel == "restart" or "r":
            main()
        else:
            bevitel = input("Helytelen. Írd be melyik karakterrel szeretnél lépni x2 vagy 01 formában!")

        a = alulvonashelye-b
        definciciók.lepesek(tomb, alulvonashelye, b)

main()
print("Köszönjük hogy velünk játszottál! Gratulálunk! Peti & Kriszti") # vége főcím