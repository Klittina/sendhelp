import random

def a(randomszamok = [], x = 100, alsohatar=-1000, felsohatar = 1000):
    for i in range (10):
        randomszamok.append(alsohatar, felsohatar)
    #np.find_nearest(x)
    print(*randomszamok)
    #return np


def ab(ok = [], k = 100, alsohatar=-1000, felsohatar = 1000):
    for i in range (10):
        ok.append(random.randint(alsohatar, felsohatar))
    print(*ok)
    print(ok[min(range(len(ok)), key=lambda i: abs(ok[i] - k))])
