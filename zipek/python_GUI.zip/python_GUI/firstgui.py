from tkinter import *

def elsogui():
    window = Tk()
    window.geometry("900x700")
    window.title("Első Python programom GUI-ban!")
    # icon = PhotoImage(file='2.png')
    # window.iconphoto(True,icon)
    window.config(background="#5cfcff")

    canv = Canvas(window, width=40, height=40, bg='white')
    canv.grid(row=2, column=3)
    img = PhotoImage(file="panda.gif")
    canv.create_image(10, 10, anchor=NW, image=img)

    label = Label(window, text="Hello World!",
                  font=('Arial', 40, 'bold'),  # betűtipus, méret beállítás
                  fg='magenta',  # betűszín beállítás#
                  bg='black',  # kis téglalap színének a beállítása#
                  relief=RAISED,
                  bd=10,
                  padx=200,
                  pady=20,
                  image=img,
                  compound="bottom")
    # label.pack() #kihelyezi a szövegek az alkalmazás legtetejére, középre, ha megváltoztatjuk a méretét, akkor is ott lesz, ahol középen lesz
    label.place(x=10,
                y=10)  # - kihelyezi a szöveget az x és y koordináta mentén. ez a hely fix, és mi állítjuk be a helyet.

    window.mainloop()

def sendhelp():
    window = Tk()
    window.geometry("900x700")
    window.title("Első Python programom GUI-ban! HAHHHH")
    window.config(background="#5cfcff")
    photo = PhotoImage('nev.gif')
    #lol = Label(image=photo)
    valaminev = Label(window, text="Hello World!",
                  font=('Arial', 40, 'bold'),  # betűtipus, méret beállítás
                  fg='magenta',  # betűszín beállítás#
                  bg='black',  # kis téglalap színének a beállítása#
                  relief=RAISED,
                  bd=10,
                  padx=200,
                  pady=20,
                  image=photo,
                  compound="bottom")
    valaminev.pack() #kihelyezi a szövegek az alkalmazás legtetejére, középre, ha megváltoztatjuk a méretét, akkor is ott lesz, ahol középen lesz
    #label.place(x=10,
     #           y=10)  # - kihelyezi a szöveget az x és y koordináta mentén. ez a hely fix, és mi állítjuk be a helyet.
    #lol.pack()

    window.mainloop()