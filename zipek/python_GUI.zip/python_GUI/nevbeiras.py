from tkinter import *

def submit(entry=Entry):
    username = entry.get()
    print("Hello " + username)

def delete():
    print()

def space():
    print()

def entrybox():
    window = Tk()

    def submit():
        username = entry.get()
        print("Hello " + username)

    entry = Entry(window,
                  font=("Arial",50))
    entry.pack(side=LEFT)
    submit_button = Button(window, text="Submit", command=submit())
    submit_button.pack(side=LEFT)

    window.mainloop()
