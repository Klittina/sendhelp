from tkinter import *

count = 0

def click():
    global count
    count+=1
    print("Megnyomtad a gombot.",count)

def buttons(db = 0):
    ablak = Tk()
    ablak.title("Gomb nyomogatás.")
    #like = PhotoImage(file='like-button-social-media-image-facebook-messenger-png-favpng-YkquKiF4ePG3tMC0eT3hxUfgS.gif')
    gomb = Button(ablak,
                  text="Click me!",
                  command=click,
                  font=("Comic Sans",30),
                  fg="Magenta",
                  bg="#00FF00",
                  activeforeground="Magenta",
                  activebackground="#00FF00",
                  state=ACTIVE)
    gomb.pack()

    ablak.mainloop()